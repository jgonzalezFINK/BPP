import React from 'react';
import Pokemon from './components/pokemon';
//import Lista from './components/Lista';

function App() {
  return (
    <div className="App">
      <Pokemon/>
    </div>
  );
}

export default App;